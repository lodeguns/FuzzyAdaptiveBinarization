# Text-Binarization

Comparison of two papers on text binarization. A rule based approach and a deep learning approach.


References: 


Kasar, T., Kumar, J. and Ramakrishnan, A.G., 2007, September. Font and background color independent text binarization. In Second international workshop on camera-based document analysis and recognition (pp. 3-9).


Calvo-Zaragoza, J., Vigliensoni, G. and Fujinaga, I., 2017, May. Pixel-wise binarization of musical documents with convolutional neural networks. In 2017 Fifteenth IAPR International Conference on Machine Vision Applications (MVA) (pp. 362-365). IEEE.
