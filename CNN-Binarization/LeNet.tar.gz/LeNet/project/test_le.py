import numpy as np
import cv2
import os
from sklearn.metrics import f1_score
import matplotlib.pyplot as plt
import random
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from keras.preprocessing.image import img_to_array
from model_zaragoza import Model
import time
import os

model = Model(17,17,3,2).build()
model.compile(loss='binary_crossentropy', optimizer='adam')

model.load_weights("./model.h5")
base_path = "./dataset_1/"
dest_path = "./dataset_1_pred/"
files = os.listdir(base_path)
for file in files:
    img = cv2.imread(base_path + file)

    slide = 16
    h = img.shape[0]
    w = img.shape[1]
    zero_mat = np.ones([h+2*slide,w+2*slide, 3]) * 255.
    for i in range(h):
        for j in range(w):
            zero_mat[i+slide, j+slide] = img[i][j][:]



    img = zero_mat
    preds = []
    out_res = np.zeros((np.shape(img)[0] -slide*2, np.shape(img)[1] -slide*2))
    r = 0
    c = 0
    start = time.time()
    for p in range(17, np.shape(img)[0] - 17):
        for q in range(17, np.shape(img)[1] - 17):
            out_res[r, c] = np.argmax(model.predict(np.asarray([img[p - 8:p + 9, q - 8:q + 9] / 255.]))) * 255.
            c += 1
        c = 0
        r += 1
    print(file, " Secs: ", (time.time() - start))
    #preds = [np.argmax(i) for i in model.predict(samples)]
    cv2.imwrite(dest_path + file, out_res)


